<script setup>
import { onMounted } from 'vue'
import { useProductStore } from '../stores/products'
import ProductCard from '../components/product/ProductCard.vue'

const productStore = useProductStore()

onMounted(async () => {
  await productStore.fetchFeaturedProducts()
  await productStore.fetchCategories()
})
</script>

<template>
  <div class="home">
    <!-- Hero Section -->
    <section class="hero">
      <div class="container">
        <div class="hero-content">
          <h1 class="hero-title">Step Into <span>Style</span></h1>
          <p class="hero-subtitle">
            Discover the perfect blend of comfort and fashion with our premium shoe collection.
            From running to casual, we've got your feet covered.
          </p>
          <div class="hero-actions">
            <router-link to="/products" class="btn btn-primary btn-lg">Shop Now</router-link>
            <router-link to="/products" class="btn btn-outline btn-lg">View Collection</router-link>
          </div>
          <div class="hero-stats">
            <div class="stat">
              <span class="stat-number">500+</span>
              <span class="stat-label">Products</span>
            </div>
            <div class="stat">
              <span class="stat-number">50+</span>
              <span class="stat-label">Brands</span>
            </div>
            <div class="stat">
              <span class="stat-number">10K+</span>
              <span class="stat-label">Customers</span>
            </div>
          </div>
        </div>
        <div class="hero-image">
          <img src="https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600&h=400&fit=crop" alt="Featured Shoe" />
        </div>
      </div>
    </section>

    <!-- Categories Section -->
    <section class="categories">
      <div class="container">
        <h2 class="section-title">Shop by Category</h2>
        <p class="section-subtitle">Find the perfect shoes for every occasion</p>
        <div class="categories-grid">
          <router-link 
            v-for="category in productStore.categories" 
            :key="category.id"
            :to="`/category/${category.slug}`"
            class="category-card"
          >
            <div class="category-image">
              <img :src="category.image || 'https://images.unsplash.com/photo-1460353581641-37baddab0fa2?w=300&h=300&fit=crop'" :alt="category.name" />
            </div>
            <div class="category-info">
              <h3>{{ category.name }}</h3>
              <span class="category-count">{{ category.products_count }} Products</span>
            </div>
          </router-link>
        </div>
      </div>
    </section>

    <!-- Featured Products Section -->
    <section class="featured">
      <div class="container">
        <div class="section-header">
          <div>
            <h2 class="section-title">Featured Products</h2>
            <p class="section-subtitle">Our most popular picks for you</p>
          </div>
          <router-link to="/products" class="btn btn-outline">View All</router-link>
        </div>
        <div class="products-grid">
          <ProductCard 
            v-for="product in productStore.featuredProducts" 
            :key="product.id" 
            :product="product"
          />
        </div>
      </div>
    </section>

    <!-- Promo Banner -->
    <section class="promo-banner">
      <div class="container">
        <div class="promo-content">
          <h2>Get 20% Off Your First Order</h2>
          <p>Sign up today and receive exclusive discounts on your favorite shoes.</p>
          <router-link to="/register" class="btn btn-primary btn-lg">Sign Up Now</router-link>
        </div>
      </div>
    </section>

    <!-- Features Section -->
    <section class="features">
      <div class="container">
        <div class="features-grid">
          <div class="feature-card">
            <div class="feature-icon">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <rect x="1" y="3" width="15" height="13"></rect>
                <polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon>
                <circle cx="5.5" cy="18.5" r="2.5"></circle>
                <circle cx="18.5" cy="18.5" r="2.5"></circle>
              </svg>
            </div>
            <h3>Free Shipping</h3>
            <p>On orders over $100</p>
          </div>
          <div class="feature-card">
            <div class="feature-icon">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>
              </svg>
            </div>
            <h3>24/7 Support</h3>
            <p>Round-the-clock assistance</p>
          </div>
          <div class="feature-card">
            <div class="feature-icon">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polyline points="23 4 23 10 17 10"></polyline>
                <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/>
              </svg>
            </div>
            <h3>Easy Returns</h3>
            <p>30-day return policy</p>
          </div>
          <div class="feature-card">
            <div class="feature-icon">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
              </svg>
            </div>
            <h3>Secure Payment</h3>
            <p>100% secure checkout</p>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<style scoped>
.hero {
  background: linear-gradient(135deg, var(--gray-100) 0%, white 100%);
  padding: 4rem 0;
}

.hero .container {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 4rem;
  align-items: center;
}

.hero-title {
  font-size: 3.5rem;
  font-weight: 800;
  line-height: 1.1;
  color: var(--gray-900);
  margin-bottom: 1.5rem;
}

.hero-title span {
  color: var(--primary);
}

.hero-subtitle {
  font-size: 1.25rem;
  color: var(--gray-600);
  margin-bottom: 2rem;
  max-width: 500px;
}

.hero-actions {
  display: flex;
  gap: 1rem;
  margin-bottom: 3rem;
}

.hero-stats {
  display: flex;
  gap: 3rem;
}

.stat {
  display: flex;
  flex-direction: column;
}

.stat-number {
  font-size: 2rem;
  font-weight: 700;
  color: var(--gray-900);
}

.stat-label {
  color: var(--gray-500);
  font-size: 0.875rem;
}

.hero-image {
  position: relative;
}

.hero-image img {
  border-radius: 2rem;
  box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25);
  transform: rotate(-5deg);
  transition: transform 0.3s;
}

.hero-image:hover img {
  transform: rotate(0deg);
}

.categories,
.featured,
.features {
  padding: 5rem 0;
}

.section-title {
  font-size: 2rem;
  font-weight: 700;
  color: var(--gray-900);
  margin-bottom: 0.5rem;
}

.section-subtitle {
  color: var(--gray-500);
  margin-bottom: 2rem;
}

.section-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-end;
  margin-bottom: 2rem;
}

.categories-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 1.5rem;
}

.category-card {
  background: white;
  border-radius: 1rem;
  overflow: hidden;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
  transition: transform 0.3s, box-shadow 0.3s;
}

.category-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 10px 25px rgba(0,0,0,0.15);
}

.category-image {
  height: 200px;
  overflow: hidden;
}

.category-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform 0.3s;
}

.category-card:hover .category-image img {
  transform: scale(1.1);
}

.category-info {
  padding: 1.5rem;
  text-align: center;
}

.category-info h3 {
  font-size: 1.125rem;
  font-weight: 600;
  margin-bottom: 0.5rem;
}

.category-count {
  color: var(--gray-500);
  font-size: 0.875rem;
}

.products-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 1.5rem;
}

.promo-banner {
  background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
  padding: 4rem 0;
  margin: 4rem 0;
}

.promo-content {
  text-align: center;
  color: white;
}

.promo-content h2 {
  font-size: 2.5rem;
  font-weight: 700;
  margin-bottom: 1rem;
}

.promo-content p {
  font-size: 1.125rem;
  opacity: 0.9;
  margin-bottom: 2rem;
}

.promo-content .btn {
  background: white;
  color: var(--primary);
}

.promo-content .btn:hover {
  background: var(--gray-100);
}

.features-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 2rem;
}

.feature-card {
  text-align: center;
  padding: 2rem;
}

.feature-icon {
  width: 60px;
  height: 60px;
  margin: 0 auto 1rem;
  background: rgba(37, 99, 235, 0.1);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
}

.feature-icon svg {
  width: 28px;
  height: 28px;
  color: var(--primary);
}

.feature-card h3 {
  font-size: 1.125rem;
  font-weight: 600;
  margin-bottom: 0.5rem;
}

.feature-card p {
  color: var(--gray-500);
  font-size: 0.875rem;
}

@media (max-width: 1024px) {
  .hero .container {
    grid-template-columns: 1fr;
    text-align: center;
  }
  
  .hero-subtitle {
    margin: 0 auto 2rem;
  }
  
  .hero-actions {
    justify-content: center;
  }
  
  .hero-stats {
    justify-content: center;
  }
  
  .hero-image {
    display: none;
  }
  
  .categories-grid,
  .products-grid,
  .features-grid {
    grid-template-columns: repeat(2, 1fr);
  }
}

@media (max-width: 640px) {
  .hero-title {
    font-size: 2.5rem;
  }
  
  .hero-actions {
    flex-direction: column;
  }
  
  .categories-grid,
  .products-grid,
  .features-grid {
    grid-template-columns: 1fr;
  }
  
  .section-header {
    flex-direction: column;
    align-items: flex-start;
    gap: 1rem;
  }
}
</style>
