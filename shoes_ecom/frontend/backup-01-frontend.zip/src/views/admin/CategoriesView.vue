<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'

const categories = ref([])
const loading = ref(true)
const showModal = ref(false)
const editingCategory = ref(null)
const form = ref({ name: '', description: '', image: '' })
const error = ref('')

const fetchCategories = async () => {
  loading.value = true
  try {
    const response = await axios.get('/api/admin/categories')
    categories.value = response.data
  } catch (error) {
    console.error('Error:', error)
  } finally {
    loading.value = false
  }
}

const openModal = (category = null) => {
  editingCategory.value = category
  form.value = category ? { ...category } : { name: '', description: '', image: '' }
  error.value = ''
  showModal.value = true
}

const closeModal = () => {
  showModal.value = false
  editingCategory.value = null
}

const handleSubmit = async () => {
  error.value = ''
  try {
    if (editingCategory.value) {
      await axios.put(`/api/admin/categories/${editingCategory.value.id}`, form.value)
    } else {
      await axios.post('/api/admin/categories', form.value)
    }
    closeModal()
    await fetchCategories()
  } catch (err) {
    error.value = err.response?.data?.message || 'Failed to save category'
  }
}

const deleteCategory = async (id) => {
  if (confirm('Are you sure? Products in this category cannot be deleted.')) {
    try {
      await axios.delete(`/api/admin/categories/${id}`)
      await fetchCategories()
    } catch (err) {
      alert(err.response?.data?.message || 'Failed to delete category')
    }
  }
}

onMounted(fetchCategories)
</script>

<template>
  <div class="page">
    <div class="page-header">
      <div>
        <h1 class="page-title">Categories</h1>
        <p class="page-subtitle">Organize your products into categories</p>
      </div>
      <button @click="openModal()" class="btn primary">
        <span>+</span> Add Category
      </button>
    </div>

    <div v-if="loading" class="loading"><div class="spinner"></div></div>

    <div v-else class="card">
      <table class="table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Slug</th>
            <th>Products</th>
            <th class="text-right">Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="category in categories" :key="category.id">
            <td>
              <div class="category-cell">
                <img v-if="category.image" :src="category.image" :alt="category.name" />
                <div v-else class="category-placeholder">📁</div>
                <span class="category-name">{{ category.name }}</span>
              </div>
            </td>
            <td><code class="slug">{{ category.slug }}</code></td>
            <td><span class="badge blue">{{ category.products_count }} products</span></td>
            <td class="text-right">
              <div class="actions">
                <button @click="openModal(category)" class="action-btn edit">✏️</button>
                <button @click="deleteCategory(category.id)" class="action-btn delete">🗑️</button>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <div v-if="showModal" class="modal-overlay" @click.self="closeModal">
      <div class="modal">
        <div class="modal-header">
          <h3>{{ editingCategory ? 'Edit Category' : 'Add Category' }}</h3>
          <button @click="closeModal" class="close-btn">&times;</button>
        </div>
        <form @submit.prevent="handleSubmit">
          <div class="modal-body">
            <div v-if="error" class="error-msg">{{ error }}</div>
            <div class="form-group">
              <label>Name *</label>
              <input v-model="form.name" type="text" required />
            </div>
            <div class="form-group">
              <label>Description</label>
              <textarea v-model="form.description" rows="3"></textarea>
            </div>
            <div class="form-group">
              <label>Image URL</label>
              <input v-model="form.image" type="url" />
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" @click="closeModal" class="btn secondary">Cancel</button>
            <button type="submit" class="btn primary">{{ editingCategory ? 'Update' : 'Create' }}</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>

<style scoped>
.page { padding: 0; }
.page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; }
.page-title { font-size: 28px; font-weight: 700; color: #111827; }
.page-subtitle { color: #6b7280; margin-top: 4px; }
.btn { display: inline-flex; align-items: center; gap: 8px; padding: 10px 20px; font-size: 14px; font-weight: 600; border-radius: 10px; border: none; cursor: pointer; }
.btn.primary { background: linear-gradient(135deg, #3b82f6, #8b5cf6); color: white; }
.btn.secondary { background: #f3f4f6; color: #374151; }
.card { background: white; border-radius: 16px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); overflow: hidden; }
.loading { display: flex; justify-content: center; padding: 80px; }
.spinner { width: 48px; height: 48px; border: 4px solid #e5e7eb; border-top-color: #3b82f6; border-radius: 50%; animation: spin 1s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }
.table { width: 100%; border-collapse: collapse; }
.table th { text-align: left; padding: 16px 24px; font-size: 12px; font-weight: 600; color: #6b7280; text-transform: uppercase; background: #f9fafb; }
.table td { padding: 16px 24px; border-bottom: 1px solid #f3f4f6; }
.table tr:hover td { background: #f9fafb; }
.text-right { text-align: right; }
.category-cell { display: flex; align-items: center; gap: 12px; }
.category-cell img { width: 40px; height: 40px; border-radius: 8px; object-fit: cover; }
.category-placeholder { width: 40px; height: 40px; border-radius: 8px; background: #f3f4f6; display: flex; align-items: center; justify-content: center; font-size: 20px; }
.category-name { font-weight: 600; color: #111827; }
.slug { background: #f3f4f6; padding: 4px 8px; border-radius: 6px; font-size: 12px; color: #6b7280; }
.badge { display: inline-block; padding: 4px 12px; font-size: 12px; font-weight: 600; border-radius: 9999px; }
.badge.blue { background: #dbeafe; color: #2563eb; }
.actions { display: flex; gap: 4px; justify-content: flex-end; }
.action-btn { width: 32px; height: 32px; border: none; background: none; border-radius: 8px; cursor: pointer; font-size: 16px; }
.action-btn:hover { background: #f3f4f6; }
.action-btn.delete:hover { background: #fee2e2; }
.modal-overlay { position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.5); backdrop-filter: blur(4px); display: flex; align-items: center; justify-content: center; z-index: 1000; }
.modal { background: white; border-radius: 16px; width: 100%; max-width: 500px; box-shadow: 0 25px 50px rgba(0,0,0,0.25); }
.modal-header { padding: 20px 24px; border-bottom: 1px solid #f3f4f6; display: flex; justify-content: space-between; align-items: center; }
.modal-header h3 { font-size: 18px; font-weight: 600; color: #111827; }
.close-btn { background: none; border: none; font-size: 24px; cursor: pointer; color: #9ca3af; }
.modal-body { padding: 24px; }
.modal-footer { padding: 16px 24px; border-top: 1px solid #f3f4f6; display: flex; justify-content: flex-end; gap: 12px; }
.error-msg { background: #fef2f2; color: #dc2626; padding: 12px 16px; border-radius: 10px; margin-bottom: 16px; }
.form-group { margin-bottom: 16px; }
.form-group label { display: block; font-weight: 500; margin-bottom: 6px; color: #374151; }
.form-group input, .form-group textarea { width: 100%; padding: 10px 14px; border: 1px solid #e5e7eb; border-radius: 10px; font-size: 14px; }
.form-group input:focus, .form-group textarea:focus { outline: none; border-color: #3b82f6; box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1); }
</style>
